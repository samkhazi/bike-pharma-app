BIKE PHARMA - GOOGLE PLAY KIT

Inside:
- BikePharma-play.aab   the app for the Play Console (package com.bikepharma.app, version 1.0.0, code 1).
                        Already signed with Bike Pharma's upload key: upload it as it is, never re-sign it.
- play-icon-512.png     the app icon for the store listing (512 x 512).
- logo/                 Bike Pharma logos at full size:
                          Bike Pharma Automobiles-02.png: Stacked logo, black text: for white backgrounds
                          Bike Pharma Automobiles-04.png: Wide logo, black text: for white backgrounds (use this for the feature graphic)
                          Bike Pharma Automobiles-01.png: Stacked logo, white text: for dark backgrounds
                          Bike Pharma Automobiles-03.png: Wide logo, white text: for dark backgrounds
                          Bike Pharma Automobiles-08.png: Mark only, yellow gear with black piston
                          Bike Pharma Automobiles-07.png: Mark only, yellow gear with white piston
                          Bike Pharma Automobiles-05.png: Wide logo, all white
                          Bike Pharma Automobiles-06.png: Wide logo, all black
                          Bike Pharma Automobiles-09.png: Mark only, all white
                          Bike Pharma Automobiles-10.png: Mark only, all black
- texts/Store-listing.txt    app name, short and full description, category, links.
- texts/Developer-steps.txt  upload steps, app content answers, data safety draft, app transfer.
- texts/Image-prompts.txt    which customer screens to capture and the prompts for the store images.

Sam adds before submit:
- 4 to 8 phone screenshots and the 1024 x 500 feature graphic (made with the prompts).
- Contact email for the listing.
- Privacy policy link, test login for Google, delete-account link (being built by Bike Pharma).
